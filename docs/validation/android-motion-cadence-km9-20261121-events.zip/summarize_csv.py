import argparse
import csv
import json
import math
import sys
from collections import Counter, defaultdict


REQUIRED_COLUMNS = {
    "leg", "case", "ordinal", "ptsUs", "targetNs", "presentNs",
    "latchNs", "eglFrameId", "backend", "periodNs",
}
WINDOW_NS = 33_333_333


def integer(value, field, required=False):
    value = (value or "").strip()
    if not value:
        if required:
            raise ValueError(f"{field} must not be blank")
        return None
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"invalid integer in {field}: {value!r}") from exc


def quantile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    return ordered[math.ceil(q * len(ordered)) - 1]


def interval_stats(intervals, period_ns):
    ticks = Counter(math.floor(delta / period_ns + 0.5) for delta in intervals)
    return {
        "n": len(intervals),
        "p50Ms": quantile(intervals, 0.50) / 1_000_000 if intervals else None,
        "p95Ms": quantile(intervals, 0.95) / 1_000_000 if intervals else None,
        "greaterThan50ms": sum(delta > 50_000_000 for delta in intervals),
        "refreshTicks": {str(tick): ticks[tick] for tick in sorted(ticks)},
    }


def summarize_leg(leg, rows):
    rows.sort(key=lambda row: row["ordinal"])
    if len(rows) != 900:
        raise ValueError(f"leg {leg!r} has {len(rows)} rows; expected 900")

    ordinals = [row["ordinal"] for row in rows]
    if ordinals not in (list(range(900)), list(range(1, 901))):
        raise ValueError(f"leg {leg!r} has duplicate, missing, or invalid ordinals")
    if len({row["case"] for row in rows}) != 1:
        raise ValueError(f"leg {leg!r} contains mixed cases")
    if len({row["periodNs"] for row in rows}) != 1:
        raise ValueError(f"leg {leg!r} contains mixed periods")

    period_ns = rows[0]["periodNs"]
    confirmed = [row for row in rows if row["presentNs"] is not None]
    previous_present = None
    for row in rows:
        present = row["presentNs"]
        if present is not None:
            if previous_present is not None and present <= previous_present:
                raise ValueError(f"leg {leg!r} has decreasing or duplicate positive presents")
            previous_present = present

    deltas = [row["presentNs"] - row["targetNs"] for row in confirmed]
    in_window = sum(0 <= delta < WINDOW_NS for delta in deltas)
    early = sum(delta < 0 for delta in deltas)
    late = sum(delta >= WINDOW_NS for delta in deltas)

    confirmed_displays = [(row["ordinal"], row["presentNs"]) for row in confirmed]
    all_intervals = [
        confirmed_displays[i][1] - confirmed_displays[i - 1][1]
        for i in range(1, len(confirmed_displays))
    ]
    adjacent_intervals = [
        confirmed_displays[i][1] - confirmed_displays[i - 1][1]
        for i in range(1, len(confirmed_displays))
        if confirmed_displays[i][0] == confirmed_displays[i - 1][0] + 1
    ]
    target_intervals = [
        rows[i]["targetNs"] - rows[i - 1]["targetNs"]
        for i in range(1, len(rows))
    ]

    instrumented = any(
        row["latchNs"] is not None or row["eglFrameId"] or row["backend"]
        for row in rows
    )
    egl_summary = None
    if instrumented:
        backend_confirmed = {"ORIGINAL": 0, "SPATIAL": 0}
        strict_on_time = {"ORIGINAL": 0, "SPATIAL": 0}
        for row in confirmed:
            backend = row["backend"]
            if (row["latchNs"] is not None or row["eglFrameId"]) and not backend:
                raise ValueError(
                    f"leg {leg!r} has a confirmed instrumented row without a backend"
                )
            if backend:
                backend_confirmed[backend] += 1
                delta = row["presentNs"] - row["latchNs"] if row["latchNs"] else None
                if (
                    delta is not None
                    and 0 <= delta <= WINDOW_NS
                    and 0 <= row["presentNs"] - row["targetNs"] < WINDOW_NS
                ):
                    strict_on_time[backend] += 1
        egl_summary = {
            "confirmedByBackend": backend_confirmed,
            "strictOnTimeSinceLatchByBackend": strict_on_time,
        }

    return {
        "case": rows[0]["case"],
        "periodNs": period_ns,
        "baseDenominator": 900,
        "confirmed": len(confirmed),
        "inWindow": in_window,
        "early": early,
        "late": late,
        "targetToPresentMs": {
            "p50": quantile(deltas, 0.50) / 1_000_000 if deltas else None,
            "p95": quantile(deltas, 0.95) / 1_000_000 if deltas else None,
        },
        "intervalsAllConfirmed": interval_stats(all_intervals, period_ns),
        "intervalsAdjacentOrdinal": interval_stats(adjacent_intervals, period_ns),
        "consecutiveTargetIntervalMs": {
            "n": len(target_intervals),
            "p50": quantile(target_intervals, 0.50) / 1_000_000 if target_intervals else None,
            "p95": quantile(target_intervals, 0.95) / 1_000_000 if target_intervals else None,
        },
        "egl": egl_summary,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Summarize presentation evidence from a CSV file."
    )
    parser.add_argument("csv_path", help="path to the evidence CSV")
    args = parser.parse_args()

    legs = defaultdict(list)
    with open(args.csv_path, newline="", encoding="utf-8-sig") as source:
        reader = csv.DictReader(source)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("CSV header is missing or contains duplicate columns")
        missing = REQUIRED_COLUMNS - set(reader.fieldnames)
        if missing:
            raise ValueError(f"CSV is missing columns: {', '.join(sorted(missing))}")

        for line_number, record in enumerate(reader, start=2):
            if None in record:
                raise ValueError(f"CSV row {line_number} has extra fields")
            leg = (record["leg"] or "").strip()
            case = (record["case"] or "").strip()
            if not leg or not case:
                raise ValueError(f"CSV row {line_number} has a blank leg or case")
            present = integer(record["presentNs"], "presentNs")
            latch = integer(record["latchNs"], "latchNs")
            if present is not None and present <= 0:
                raise ValueError(f"CSV row {line_number} has non-positive presentNs")
            if latch is not None and latch <= 0:
                raise ValueError(f"CSV row {line_number} has non-positive latchNs")
            backend = (record["backend"] or "").strip()
            if backend and backend not in ("ORIGINAL", "SPATIAL"):
                raise ValueError(f"CSV row {line_number} has invalid backend {backend!r}")
            period = integer(record["periodNs"], "periodNs", required=True)
            if period <= 0:
                raise ValueError(f"CSV row {line_number} has non-positive periodNs")

            legs[leg].append({
                "case": case,
                "ordinal": integer(record["ordinal"], "ordinal", required=True),
                "ptsUs": integer(record["ptsUs"], "ptsUs", required=True),
                "targetNs": integer(record["targetNs"], "targetNs", required=True),
                "presentNs": present,
                "latchNs": latch,
                "eglFrameId": (record["eglFrameId"] or "").strip(),
                "backend": backend,
                "periodNs": period,
            })

    if not legs:
        raise ValueError("CSV contains no evidence rows")

    result = {
        leg: summarize_leg(leg, rows)
        for leg, rows in sorted(legs.items())
    }
    print(json.dumps(result, separators=(",", ":"), allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, csv.Error, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        sys.exit(1)
