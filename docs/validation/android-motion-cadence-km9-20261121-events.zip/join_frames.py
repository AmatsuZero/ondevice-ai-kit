"""Join exported SurfaceFlinger history to the app's 30 fps source events."""
import csv
import json
import re
import sys
import zipfile
from collections import Counter
from pathlib import Path

from tools.probes.android_realtime_sr_device import validate_decode

SHA = "e698bee8c98c3158eb5e99e26f1cbe13334b52557720b2129a3e31dd2fa67dcb"
LAYER = re.compile(r"SurfaceView\[io\.ondeviceai\.realtimesr\.demo/io\.ondeviceai\.realtimesr\.SrRunActivity\]\(BLAST\)#\d+")
COLS = "leg case ordinal ptsUs targetNs presentNs latchNs eglFrameId backend periodNs".split()
def join(z, leg):
    def read(n):
        return json.loads(z.read(f"{leg}/{n}.json"))
    run, term, layer = (read(n) for n in ("run", "terminal", "layer"))
    mode = term["case"]
    raw = z.read(f"{leg}/events.jsonl")
    error = validate_decode(term, run, raw, run["runId"], mode, SHA)
    if error: raise ValueError(error)
    if not LAYER.fullmatch(layer["name"]) or set(layer["periodSamplesNs"]) != {16666667}:
        raise ValueError("unexpected layer or sampled refresh period")
    events = list(map(json.loads, raw.splitlines()))
    by_stage = {}
    for row in events:
        if row["stage"] not in ("decodeRelease","latch","swap","display"): continue
        assert row["runId"] == run["runId"] and row["generation"] == run["generation"] and row["loop"] == 0
        group = by_stage.setdefault(row["stage"], {})
        i = row["sourceOrdinal"]
        assert i not in group and 0 <= i < 900
        group[i] = row
    decoded = by_stage["decodeRelease"]
    targets = {r["targetNs"] for r in decoded.values()}
    assert len(targets) == 900
    presents = {}
    for desired, actual, ready in layer["rows"]:
        if desired not in targets or not 0 < actual < 2**63 - 1: continue
        assert presents.setdefault(desired, actual) == actual
    assert len(set(presents.values())) == len(presents)
    for i in range(900):
        dec = decoded[i]; target = dec["targetNs"]; present = presents.get(target)
        latch = by_stage.get("latch",{}).get(i,{}).get("latchBeginNs")
        swap = by_stage.get("swap",{}).get(i,{})
        display = by_stage.get("display",{}).get(i,{})
        backend = fid = None
        if mode == "original":
            assert not (latch or swap or display)
        elif display:
            assert display["eglFrameId"] == swap["eglFrameId"] and swap["reason"] != "swap_failed"
            # Missing SF samples must never be synthesized from a positive EGL record.
            if present is not None: assert display["displayNs"] == present
            fid = display["eglFrameId"]; backend = swap["submittedBackend"]
        if mode != "original" and present is not None:
            assert display and latch and backend in ("ORIGINAL","SPATIAL")
        yield [leg,mode,i,dec["ptsUs"],target,present,latch,fid,backend,16666667]

def main():
    with zipfile.ZipFile(sys.argv[1]) as z, open(sys.argv[2], "x", newline="") as f:
        writer = csv.writer(f); writer.writerow(COLS)
        for leg in json.loads(z.read("index.json"))["primaryLegs"]:
            writer.writerows(join(z,leg))
if __name__ == "__main__":main()
