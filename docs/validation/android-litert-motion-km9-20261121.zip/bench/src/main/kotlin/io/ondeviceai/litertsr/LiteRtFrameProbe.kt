package io.ondeviceai.litertsr

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class LiteRtFrameProbe : Activity() {
    companion object {
        private const val TAG = "LiteRtFrameProbe"
        private const val LIMIT_NS = 150_000_000_000L
    }

    private var started = false
    private var resultDir: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (savedInstanceState != null || started) return
        started = true

        val result = File(filesDir, "result")
        if (result.exists()) {
            Log.e(TAG, "Refusing existing result directory")
            return
        }
        if (!result.mkdir()) {
            Log.e(TAG, "Could not create result directory")
            return
        }
        resultDir = result

        Thread({
            runBenchmark(result)
        }, "LiteRtFrameProbe").start()
    }

    private fun runBenchmark(result: File) {
        var warmupNs = 0L
        val scenes = JSONArray()
        var terminalStatus = "failed"
        var terminalError: Throwable? = null
        var interpreter: EsrganInterpreter? = null

        try {
            val input = File(filesDir, "input")
            val model = File(input, "model.tflite")
            if (!model.isFile) throw IllegalStateException("Missing model: ${model.absolutePath}")

            val specs = arrayOf(
                intArrayOf(1, 640, 360),
                intArrayOf(2, 480, 270),
                intArrayOf(3, 640, 360)
            )
            val decoded = mutableListOf<Triple<Int, Int, IntArray>>()

            for (spec in specs) {
                val scene = spec[0]
                val width = spec[1]
                val height = spec[2]
                val png = File(input, "$scene.png")
                if (!png.isFile) throw IllegalStateException("Missing scene: ${png.absolutePath}")

                val options = BitmapFactory.Options().apply {
                    inScaled = false
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bitmap = BitmapFactory.decodeFile(png.absolutePath, options)
                    ?: throw IllegalStateException("Could not decode scene $scene")

                try {
                    if (bitmap.width != width || bitmap.height != height) {
                        throw IllegalStateException(
                            "Scene $scene has ${bitmap.width}x${bitmap.height}; expected ${width}x${height}"
                        )
                    }

                    val pixels = IntArray(width * height)
                    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                    for (pixel in pixels) {
                        if ((pixel ushr 24) != 255) {
                            throw IllegalStateException("Scene $scene is not opaque")
                        }
                    }
                    decoded.add(Triple(scene, width, pixels))
                } finally {
                    bitmap.recycle()
                }
            }

            interpreter = EsrganInterpreter(model)

            val first = decoded[0]
            val warmupPixels = IntArray(50 * 50)
            val firstWidth = first.second
            val firstSource = first.third
            for (y in 0 until 50) {
                val sourceOffset = y * firstWidth
                val targetOffset = y * 50
                for (x in 0 until 50) {
                    warmupPixels[targetOffset + x] = firstSource[sourceOffset + x]
                }
            }

            val warmupStart = SystemClock.elapsedRealtimeNanos()
            val warmupOutput = interpreter!!.infer(warmupPixels)
            warmupNs = SystemClock.elapsedRealtimeNanos() - warmupStart
            if (warmupOutput.size != 40_000) {
                throw IllegalStateException("Warmup output size was ${warmupOutput.size}; expected 40000")
            }

            for ((scene, width, sourcePixels) in decoded) {
                var completedTiles = 0
                val tileNs = ArrayList<Long>()
                val fullStart = SystemClock.elapsedRealtimeNanos()
                var fullNs = 0L
                var timedOut = false
                var output: IntArray? = null

                try {
                    output = EsrganTiles.upscale(
                        sourcePixels,
                        width,
                        if (scene == 1) 360 else if (scene == 2) 270 else 360,
                        checkpoint = {
                            completedTiles++
                            if (completedTiles % 20 == 0) {
                                Log.i(TAG, "Scene $scene checkpoint: $completedTiles tiles")
                            }
                        },
                        infer = { tile ->
                            val tileStart = SystemClock.elapsedRealtimeNanos()
                            val tileOutput = try {
                                interpreter!!.infer(tile)
                            } finally {
                                val elapsed = SystemClock.elapsedRealtimeNanos() - tileStart
                                if (elapsed > 0L) tileNs.add(elapsed)
                            }

                            if (tileOutput.size != 40_000) {
                                throw IllegalStateException(
                                    "Scene $scene infer output size was ${tileOutput.size}; expected 40000"
                                )
                            }

                            val elapsedFull = SystemClock.elapsedRealtimeNanos() - fullStart
                            if (elapsedFull >= LIMIT_NS) {
                                throw SceneTimeoutException()
                            }
                            tileOutput
                        }
                    )
                    fullNs = SystemClock.elapsedRealtimeNanos() - fullStart
                    if (fullNs >= LIMIT_NS) timedOut = true
                } catch (_: SceneTimeoutException) {
                    timedOut = true
                    fullNs = SystemClock.elapsedRealtimeNanos() - fullStart
                }

                val sceneJson = JSONObject()
                    .put("scene", scene)
                    .put("width", width)
                    .put("height", if (scene == 2) 270 else 360)
                    .put("fullNs", fullNs)
                    .put("tileNs", JSONArray(tileNs))

                val expectedTiles = ((width + 33) / 34) *
                    (((if (scene == 2) 270 else 360) + 33) / 34)
                if (timedOut) {
                    sceneJson.put("completedTiles", completedTiles)
                    scenes.put(sceneJson)
                    throw SceneTimeoutException()
                }

                if (completedTiles != expectedTiles) {
                    throw IllegalStateException(
                        "Scene $scene tile count was $completedTiles; expected $expectedTiles"
                    )
                }
                if (tileNs.size != completedTiles) {
                    throw IllegalStateException(
                        "Scene $scene measured infer calls ${tileNs.size}; completed tiles $completedTiles"
                    )
                }

                val height = if (scene == 2) 270 else 360
                val resultPixels = output
                    ?: throw IllegalStateException("Scene $scene produced no output")
                val expectedOutput = width * height * 16
                if (resultPixels.size != expectedOutput) {
                    throw IllegalStateException(
                        "Scene $scene output size was ${resultPixels.size}; expected $expectedOutput"
                    )
                }

                val outWidth = width * 4
                val outHeight = height * 4
                val outBitmap = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
                try {
                    outBitmap.setPixels(resultPixels, 0, outWidth, 0, 0, outWidth, outHeight)
                    val frame = File(result, "$scene-out.png")
                    FileOutputStream(frame).use { stream ->
                        if (!outBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) {
                            throw IllegalStateException("Could not encode scene $scene PNG")
                        }
                        stream.flush()
                    }
                    val relativeFrame = "result/$scene-out.png"
                    sceneJson.put("frame", relativeFrame)
                    sceneJson.put("output", relativeFrame)
                } finally {
                    outBitmap.recycle()
                }

                scenes.put(sceneJson)
            }

            terminalStatus = "completed"
        } catch (error: Throwable) {
            terminalError = error
            terminalStatus = "failed"
            Log.e(TAG, "LiteRtFrameProbe failed", error)
        } finally {
            try {
                interpreter?.close()
            } catch (closeError: Throwable) {
                if (terminalError == null) {
                    terminalError = closeError
                    terminalStatus = "failed"
                }
                Log.e(TAG, "Could not close interpreter", closeError)
            }

            val report = JSONObject()
                .put("status", terminalStatus)
                .put("warmupNs", warmupNs)
                .put("scenes", scenes)
            if (terminalError != null) {
                report.put(
                    "error",
                    JSONObject()
                        .put("type", terminalError!!.javaClass.name)
                        .put("message", terminalError!!.message ?: "")
                )
            }

            writeAtomicReport(result, report)
        }
    }

    private fun writeAtomicReport(result: File, report: JSONObject) {
        val reportFile = File(result, "report.json")
        val temp = File(result, "report.json.tmp")
        try {
            FileOutputStream(temp, false).use { stream ->
                stream.write(report.toString().toByteArray(Charsets.UTF_8))
                stream.flush()
                stream.fd.sync()
            }
            if (!temp.renameTo(reportFile)) {
                if (temp.exists()) temp.delete()
                Log.e(TAG, "Could not atomically rename report")
            }
        } catch (error: Throwable) {
            if (temp.exists()) temp.delete()
            Log.e(TAG, "Could not write terminal report", error)
        }
    }

    private class SceneTimeoutException : RuntimeException()
}
