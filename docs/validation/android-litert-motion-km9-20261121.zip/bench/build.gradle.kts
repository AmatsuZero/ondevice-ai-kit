plugins { id("com.android.application") version "9.1.0" }
android { namespace="io.ondeviceai.litertsr"; compileSdk=36; defaultConfig { applicationId="io.ondeviceai.probe.litertframes"; minSdk=26; targetSdk=36 }; compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 } }
dependencies { implementation("com.google.ai.edge.litert:litert:1.4.2") }
