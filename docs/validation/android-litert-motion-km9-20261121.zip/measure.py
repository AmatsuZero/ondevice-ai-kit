"""Host verification only. Needs the PNGs and terminal report collected from the physical benchmark."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageStat
import PIL, hashlib, math, statistics, json, subprocess, re
D=Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
as_y=lambda im:im.convert('RGB').convert('L',(0.2126,0.7152,0.0722,0.0))

def measure(im, ref, name):
    # Same 8-bit, full range BT.709 luma domain for both metrics and providers.
    a=as_y(im); b=as_y(ref); assert a.size==b.size
    diff=ImageChops.difference(a,b); mse=ImageStat.Stat(diff).rms[0]**2
    assert mse>0; psnr=10*math.log10(255**2/mse)
    paths=[]
    for obj,suffix in [(a,'a'),(b,'b')]:
        path=D/(name+'-'+suffix+'.pgm');obj.save(path);paths.append(str(path))
    proc=subprocess.run(['ffmpeg','-nostdin','-hide_banner','-i',paths[0],'-i',paths[1],'-filter_complex','[0:v][1:v]ssim','-frames:v','1','-f','null','-'],check=True,capture_output=True,text=True)
    val=float(re.search(r'All:([0-9.]+)',proc.stderr).group(1));assert 0<=val<=1
    return dict(PSNR_Y_dB=round(psnr,5),SSIM_Y=val)

j=json.loads((D/'raw-report.json').read_text());inp=json.loads((D/'inputs.json').read_text());assert j['status']=='completed' and j['warmupNs']>0 and [v['scene'] for v in j['scenes']]==[1,2,3];rows=[]
# Display at the native reference geometry. All columns have identical crop and zoom.
fontpath=Path('/System/Library/Fonts/Supplemental/Arial.ttf');font=ImageFont.truetype(str(fontpath),19) if fontpath.exists() else ImageFont.load_default();sheet=Image.new('RGB',(1040,711),'#ffffff');draw=ImageDraw.Draw(sheet)
for xx,title in enumerate(['Bilinear x4','LiteRT ESRGAN x4','Source reference']): draw.text((14+344*xx,9),title,fill='#14233a',font=font)
for k,(r,m) in enumerate(zip(j['scenes'],inp)):
    i=r['scene'];assert i==m['scene'] and m['ordinal']==90; w,h=m['inputSize'];W,H=w*4,h*4;sr=Image.open(D/f'{i}-out.png').convert('RGB');lr=Image.open(D/f'{i}.png').convert('RGB');ref=Image.open(D/f'{i}-ref.png').convert('RGB');assert sha(D/f'{i}.png')==m['inputSHA256'] and sha(D/f'{i}-ref.png')==m['referenceSHA256'];assert (r['width'],r['height'])==lr.size==(w,h) and sr.size==(W,H);t=r['tileNs'];assert len(t)==((w+33)//34)*((h+33)//34) and all(x>0 for x in t) and sum(t)<=r['fullNs'];ms=r['fullNs']/1e6;tab={**m,'outputSHA256':sha(D/f'{i}-out.png'),'outputSize':list(sr.size),'tiles':len(t),'ms':round(ms,3),'frameBudgetsAt30fps':round(ms*30/1000,2),'minTileMs':round(min(t)/1e6,3),'medianTileMs':round(statistics.median(t)/1e6,3),'tilesUnder33ms':sum(x*30<=10**9 for x in t)}
    base=lr.resize(sr.size,Image.Resampling.BILINEAR);base=base.resize(ref.size,Image.Resampling.LANCZOS);back=sr.resize(ref.size,Image.Resampling.LANCZOS);assert ImageChops.difference(back,base).getbbox();tab['referenceNote']='native-resolution reconstruction only; no higher-detail reference' if ref.size==lr.size else 'same source frame, available source resolution';tab['bilinear']=measure(base,ref,f'{i}-bilinear');tab['LiteRT']=measure(back,ref,f'{i}-sr');rows.append(tab)
    sx,sy=[(0.27,0.58),(0.51,0.50),(0.85,0.34)][k];cw,ch=164,88;x=max(0,min(ref.width-cw,int(ref.width*sx-cw/2)));y=max(0,min(ref.height-ch,int(ref.height*sy-ch/2)))
    line=['1. Film / 360p','2. Waterfall / 270p (native-size reference)','3. Birds / 360p'][k];y0=43+219*k;draw.text((14,y0),line,fill='#314457',font=font)
    for z,img in enumerate([base,back,ref]):sheet.paste(img.crop((x,y,x+cw,y+ch)).resize((cw*2,ch*2),Image.Resampling.NEAREST),(14+344*z,y0+30))
    print(i,'fullMs',tab['ms'],'tile minimum',tab['minTileMs'],'baseline',tab['bilinear'],'LiteRT',tab['LiteRT'])
sheet.save(D/'same-frame-crops.png');(D/'measured.json').write_text(json.dumps({'warmupNs':j['warmupNs'],'hostPillow':PIL.__version__,'rows':rows},indent=2)+'\n')
