"""Recompute row 25 acceptance from the two device reads and actual per-call traces."""
import json
import sys
from pathlib import Path

def analyze(contract, attempt):
    source = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(source / "verification"))
    sys.path.insert(0, str(source / "verification/phases"))
    from verify_collected_windows import verify, read_file, require
    from pair_policy import expected_groups
    from phase_align import parse_record
    from phase_capture import quality
    root = attempt / "observation"
    host, cap = root / "host", root / "captured"
    verified = verify(contract, host, cap)
    report = json.loads(read_file(host / "terminal-observed.json"))
    rid = contract["runId"]
    records = [parse_record(line) for line in read_file(root / "phase.log").decode().splitlines()
               if line and line != "--------- beginning of main"]
    require(len(records) == contract["phaseTrace"]["expectedRecords"] == (3 if contract["reuseEncoder"] else 4), "native phase count")
    out = {}
    for index, stage in enumerate(("auto","forced")):
        window = verified["windows"][stage]
        trace = window["traceReceipt"]
        groups = {}
        tids = set()
        for group, pid, tid, stamps in records:
            require(pid == report["pid"] and tid > 0, "wrong native process")
            require(all(v > 0 for v in stamps) and sorted(stamps) == stamps, "incomplete phase timings")
            if window["enterNs"] < stamps[0] and stamps[-1] < window["exitNs"]:
                require(group not in groups, "duplicated phase")
                groups[group] = stamps
                tids.add(tid)
        require(set(groups) == set(expected_groups(contract["reuseEncoder"], stage)) and len(tids)==1,
                "unexpected native phases within stage")
        if "audio" in groups:
            require(groups["audio"][-1] <= groups["text"][0], "overlapping audio/text")
        out[stage] = dict(markers=trace["markers"], traceReceipt=trace, groups=groups, tid=tids.pop(),
                          innerDecodeMs=(window["exitNs"]-window["enterNs"])/1e6,
                          rawText=window["rawText"])
    require(out["auto"]["tid"] == out["forced"]["tid"], "native thread differs")
    match = quality(read_file(source/"project/test-assets/cases.json"), contract["caseManifest"],
                    contract["fixture"], {s:r["rawText"] for s,r in out.items()})
    restored=json.loads(read_file(root/"restored.json"))
    require(restored["packageListRestored"] is True and not restored["errors"], "package restoration")
    row, = report["rows"]
    require(0 < report["loadNanos"] <= 120_000_000_000 and 0 < row["caseNanos"] <= 120_000_000_000,
            "device timing limit")
    return dict(runId=rid, sourceFingerprint=verified["sourceFingerprint"], terminalSHA256=verified["terminalReportSha256"],
                pid=report["pid"],startTicks=report["processStartTicks"],stages=out,referenceMatch=match,
                rssPeakSampledBytes=verified["sampledMaxRssBytes"],processSamples=verified["processSamples"],
                loadMs=report["loadNanos"]/1e6,caseMs=row["caseNanos"]/1e6,
                terminalAck=True,doubleRead=True,restored=restored,model=contract["models"]["decoder.int8.onnx"])

