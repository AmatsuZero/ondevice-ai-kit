package io.ondeviceai.acceptance.qwenfile

internal object PairArm {
    fun enabled(runId: String?): Boolean = when (runId) {
        "w3-pair25-20261123-a1", "w3-pair25-20261123-a2" -> false
        "w3-pair25-20261123-b1", "w3-pair25-20261123-b2" -> true
        else -> throw IllegalArgumentException("Unknown run ID")
    }

    fun configure(runId: String) {
        val reuse = if (enabled(runId)) "1" else "0"
        android.system.Os.setenv("W3_REUSE_ENCODER", reuse, true)
        android.system.Os.setenv("W3_REUSE_ENCODER_DIAGNOSTIC", "1", true)
    }

    fun expectedMarkers(runId: String?, stage: String): List<String> {
        val reuse = enabled(runId)
        require(stage == "auto" || stage == "forced") { "Unknown stage" }

        return if (stage == "auto" || !reuse) {
            listOf("W3CALL conv", "W3CALL encoder", "W3FRAMES 129")
        } else {
            listOf("W3REUSE hit", "W3FRAMES 129")
        }
    }
}
