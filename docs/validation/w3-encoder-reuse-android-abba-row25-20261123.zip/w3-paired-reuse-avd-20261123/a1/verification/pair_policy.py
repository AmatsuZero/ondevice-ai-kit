def expected_markers(reuse, stage):
    if type(reuse) is not bool:
        raise TypeError("reuse must be bool")
    if stage not in ("auto", "forced"):
        raise ValueError("unknown stage")
    if stage == "auto" or not reuse:
        return ["W3CALL conv", "W3CALL encoder", "W3FRAMES 129"]
    return ["W3REUSE hit", "W3FRAMES 129"]


def expected_groups(reuse, stage):
    if type(reuse) is not bool:
        raise TypeError("reuse must be bool")
    if stage not in ("auto", "forced"):
        raise ValueError("unknown stage")
    if stage == "auto" or not reuse:
        return ("audio", "text")
    return ("text",)
