"""Replay every arm from its original disk evidence; no device access."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
order = ("a1", "b1", "b2", "a2")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def one(arm):
    base = root / arm
    config = json.loads((base / "contract.json").read_bytes())
    assert config["reuseEncoder"] is arm.startswith("b")
    rid = config["runId"]
    run = root.parent / rid
    attempt, = run.glob("attempt-*")
    receipt = json.loads((attempt / "preflight.json").read_bytes())
    assert receipt["contract"] == digest(base / "contract.json")
    assert receipt["runId"] == rid and receipt["reuseEncoder"] is config["reuseEncoder"]
    for name, expected in config["verificationFiles"].items():
        assert digest(base / name) == expected, name
    assert (attempt / "devices-delta.txt").read_text() == "added=\nremoved=\n"
    obs = attempt / "observation"
    installs = json.loads((obs / "installed.json").read_bytes())
    assert installs == {v["package"]:v["sha256"] for v in config["apks"].values()}
    before = json.loads((obs / "before-launch-resource.json").read_bytes())
    assert before["availableBytes"] >= before["minimum"] == config["minimumInitialAvailableBytes"]
    sys.path.insert(0, str(base / "launch"))
    if arm == "a1":
        assert digest(base / "launch/reuse_evidence_replay.py") == digest(root / "b1/launch/reuse_evidence.py")
        from reuse_evidence_replay import analyze
    else:
        from reuse_evidence import analyze
    actual = analyze(config, attempt)
    original = "analysis-replay.json" if arm == "a1" else "analysis.json"
    assert actual == json.loads((attempt / original).read_bytes())
    assert actual["referenceMatch"]["bothExact"] and actual["restored"]["packageListRestored"]
    print(json.dumps({"runId":rid, "reuse":config["reuseEncoder"],
        "autoMs":actual["stages"]["auto"]["innerDecodeMs"],
        "forcedMs":actual["stages"]["forced"]["innerDecodeMs"],
        "rssMiB":actual["rssPeakSampledBytes"]/1048576,
        "samples":actual["processSamples"],"caseMs":actual["caseMs"],
        "terminalSHA256":actual["terminalSHA256"]}))
if __name__ == "__main__":
    if len(sys.argv) == 2:
        if sys.argv[1] not in order:
            raise SystemExit("unknown arm")
        one(sys.argv[1])
    else:
        configs = [json.loads((root / arm / "contract.json").read_bytes()) for arm in order]
        for key in ("inputs","sourceFingerprint","apks","models","fixture","sherpaJniSHA256","onnxRuntimeSHA256"):
            assert all(c[key] == configs[0][key] for c in configs)
        for arm in order:
            subprocess.run([sys.executable,"-B",__file__,arm],check=True)
