"""Parent-side acceptance for a single encoder-reuse batch on a disposable AVD."""
import hashlib
import importlib.util
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

if not __debug__:
    raise SystemExit("assertions required")

root = Path(__file__).resolve().parent
art = root.parent
repo = art.parent.parent
pair = art / "w3-paired-reuse-avd-20261123/b2"
batch = repo / "probes/android-qwen-prefill-release/lastrow/batch"
host = root / "host-tools"
sys.path[:0] = [str(host), str(batch), str(pair/"launch"), str(pair/"host-src")]
import batch_prepared
import batch_source
import score_batch
import batch_collect
import phone_probe
from adb_process_sampler import AdbProcessSampler
import phase_avd

contract = root / "contract.json"
c = json.loads(contract.read_bytes())
assert hashlib.sha256(contract.read_bytes()).hexdigest() == batch_prepared._DIGEST == score_batch.CONTRACT
apk = json.loads((root / "verified-apks.json").read_bytes())
assert apk["bothV2Verified"] and apk["runId"] == c["runId"]
assert c["runId"] == "w3-reuse-batch65-avd-20261124-02"
assert c["app"] == "io.ondeviceai.acceptance.qwenreusebatch"
assert phase_avd.SERIAL == "emulator-5594"
model_root = art / "w3-full-decoder-20261122-OKEJZ39P/candidate/model-inputs"
io = score_batch.load_file_module("avd_io", art / "w3-window-notebook-20261122-01/run_once.py")
io.app, io.rid, io.serial = c["app"], c["runId"], phase_avd.SERIAL
evidence = root / "avd-evidence"
attempt = evidence / "phone-attempt"
io.root = attempt
io.captured = attempt / "captured"
io.model = "no_backup/qwen3-asr-0.6b-int8-393f8a14"
io.helper = "files/w3-ack-tools/rename_noreplace"
io.terminal = "files/w3-qwen-terminal"
io.record = lambda name, obj: (attempt / name).write_text(json.dumps(obj, indent=2) + "\n")
plain_run = io.run
rid, fp = c["runId"], c["sourceFingerprint"]
instrumentation = None

def launch_instrumentation(*args, **kwargs):
    global instrumentation
    if instrumentation is not None:
        raise RuntimeError("instrumentation already launched")
    instrumentation = subprocess.Popen(*args, **kwargs)
    return instrumentation

def device():
    os.kill(int((evidence / "emulator.pid").read_text()), 0)
    assert io.serial == "emulator-5594" and plain_run("emu","avd","name").decode().splitlines()==[phase_avd.NAME,"OK"]
    assert io.shell("getprop","ro.kernel.qemu")=="1"

def digest_installed(pkg):
    entry, = io.shell("pm","path",pkg).splitlines()
    assert entry.startswith("package:")
    return io.shell("sha256sum",entry[8:]).split()[0]

def ownership():
    device()
    for row in apk["apks"].values():
        assert digest_installed(row["package"])==row["sha256"]

def ready():
    ownership()
    assert "instrumentation:"+c["runner"]+" (target="+io.app+")" in io.shell("pm","list","instrumentation").splitlines()
    assert phone_probe._mem_available_kb(io)*1024>=c["plan"]["deviceAvailableStopBelowBytes"]

def observed_run(*args, **kwargs):
    data = plain_run(*args, **kwargs)
    if not data.startswith(b'D{') or (attempt / "ack-published.json").exists():
        return data
    report = json.loads(data[1:])
    if not report["terminal"]:
        return data
    assert (report["runId"],report["sourceFingerprint"],report["probeVariant"]) == (rid,fp,c["plan"]["probeVariant"])
    pid, ticks = report["pid"], report["processStartTicks"]
    def still_same():
        device()
        assert io.shell("pidof",io.app) == str(pid)
        assert batch_source.ticks_from_stat(io.private("cat",f"/proc/{pid}/stat"),pid) == ticks
        assert plain_run(*args, **kwargs) == data
    def terminal_sample(name):
        still_same()
        sample = AdbProcessSampler(io.adb, io.serial, io.app, pid, ticks).sample()
        io.record(name, sample)
        assert sample["pid"] == pid and sample["startTicks"] == ticks
        assert 0 < sample["rssBytes"] <= c["plan"]["sampledRssStopAboveBytes"]
        assert sample["deviceAvailableBytes"] >= c["plan"]["deviceAvailableStopBelowBytes"]
        still_same()
    terminal_sample("terminal-observed-sample.json")
    (attempt / "terminal-before-ack.raw").write_bytes(data[1:])
    digest = hashlib.sha256(data[1:]).hexdigest()
    payload = (chr(10).join(["ODAI-TERMINAL-ACK-v1",rid,fp,str(pid),ticks,digest])+chr(10)).encode("ascii")
    from adb_terminal_ack_rename_publisher import AdbTerminalAckRenamePublisher
    publisher = AdbTerminalAckRenamePublisher(io.adb,io.serial,io.app,rid,helper_sha256=c["ackHelperSHA256"])
    receipt = publisher.publish(payload,before_link=lambda: terminal_sample("terminal-before-publish-sample.json"))
    io.record("ack-published.json",dict(receipt,reportSHA256=digest,pid=pid,startTicks=ticks))
    # After the device receives the ACK it may exit immediately. Consume the
    # instrumentation finish here while the monitor holds the terminal sample.
    assert receipt["published"] is True and receipt["durability_verified"] is True
    assert instrumentation.wait(timeout=15) == 0
    from terminal_device_lifecycle import parse_instrumentation_finish
    finish = parse_instrumentation_finish(
        (attempt / "host/instrumentation.log").read_bytes(),
        expected_report_sha256=digest, terminal_status=report["status"])
    io.record("finish-verified.json", finish)
    return data

def grade(report,host_result,samples):
    return score_batch.score(repo,contract,root/"project/test-assets/cases.json",report,host_result,samples)

def run():
    attempt.mkdir()
    device()
    before = io.packages()
    assert not {c["app"],c["test"]}.intersection(before)
    assert io.shell("getprop","ro.build.version.sdk")=="37" and io.shell("getconf","PAGE_SIZE")=="16384"
    assert io.shell("getprop","ro.product.cpu.abi")=="arm64-v8a"
    io.record("before.json",dict(packages=before,serial=io.serial,api=37,pageSize=16384,availableKb=phone_probe._mem_available_kb(io)))
    installed=[]
    try:
        for role,row in apk["apks"].items():
            leaf = "androidTest/debug" if role=="test" else "debug"
            file, = (root/"project/build/outputs/apk"/leaf).glob("*.apk")
            assert hashlib.sha256(file.read_bytes()).hexdigest()==row["sha256"]
            device()
            assert plain_run("install",str(file),timeout=60).decode().strip().endswith("Success")
            assert digest_installed(row["package"])==row["sha256"]
            installed.append(row["package"])
        io.record("installed.json",installed)
        io.private("mkdir","-p","files/w3-ack-tools",io.model+"/tokenizer")
        transfers = [io.upload(art/"w3-decode-window-20261122-GXmgFj/rename_noreplace",io.helper,c["ackHelperSHA256"],"500")]
        for name,meta in c["models"].items():
            device()
            transfers.append(io.upload(model_root/name,io.model+"/"+name,meta["sha256"],"400"))
        io.record("transfers.json",transfers)
        io.shell("input","keyevent","KEYCODE_WAKEUP")
        io.shell("wm","dismiss-keyguard")
        io.shell("svc","power","stayon","true")
        ready()
        io.run = observed_run
        print("starting batch",rid,flush=True)
        result = batch_collect.run_and_collect(attempt,contract,io,ready,ownership,AdbProcessSampler,grade,
                                               popen=launch_instrumentation)
        print("batch scored",result["completedRows"],result["reportAndSamplesComplete"],flush=True)
    finally:
        io.run = plain_run
        if (attempt/"run-started.json").exists():
            device()
            io.captured.mkdir()
            io.identity=device
            io.collect()
        for pkg in reversed(installed):
            device()
            assert digest_installed(pkg)==next(r["sha256"] for r in apk["apks"].values() if r["package"]==pkg)
            assert plain_run("uninstall",pkg).decode().strip()=="Success"
        after=io.packages()
        io.record("restored.json",dict(uninstalled=list(reversed(installed)),added=sorted(set(after)-set(before)),removed=sorted(set(before)-set(after))))
        assert before==after

if __name__=="__main__":
    evidence.mkdir()
    phase_avd.run_on_avd(evidence,run)

